package principal;


class Main {
  

	 public static void main(String[] args) {
		 //Description du jeu
		 System.out.println("#Projet de session en Intelligence artificièle distribuée");
		 System.out.println("#Réaliser par Diallo Alhassane, Manel Haddad, Aboubacar Diakité");
		 System.out.println();
		 System.out.println();
		 System.out.println("---------------------------Debut du jeu !---------------------------------");

		 System.out.println();

		 new Simulateur(10, 15, 1500, 10);
		 System.out.println();
		    System.out.println("--------------------Fin du jeu !--------------------------");
	    }

	    
}